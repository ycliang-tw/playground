/* Generated automatically. */
static const char configuration_arguments[] = "/local/home/users3/ycliang/toolchain/riscv-gnu-toolchain/riscv-gcc/configure --target=riscv64-linux --prefix=/local/home/users3/ycliang/toolchain/cross/riscv64-linux --with-sysroot=/local/home/users3/ycliang/toolchain/cross/riscv64-linux/sysroot --with-newlib --without-headers --disable-shared --disable-threads --with-system-zlib --enable-tls --enable-languages=c --disable-libatomic --disable-libmudflap --disable-libssp --disable-libquadmath --disable-libgomp --disable-nls --disable-bootstrap --src=.././riscv-gcc --enable-multilib --with-abi=lp64d --with-arch=rv64imafdc --with-tune=rocket --with-isa-spec=2.2 'CFLAGS_FOR_TARGET=-O2   -mcmodel=medlow' 'CXXFLAGS_FOR_TARGET=-O2   -mcmodel=medlow'";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "abi", "lp64d" }, { "arch", "rv64imafdc" }, { "tune", "rocket" }, { "isa_spec", "2.2" } };
